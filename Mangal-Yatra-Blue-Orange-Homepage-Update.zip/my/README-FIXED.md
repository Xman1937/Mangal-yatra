# Mangal Yatra – Fix for demo UUID Save/Edit/Delete error

## What was fixed
- When Supabase is configured, the app no longer initializes the live UI with `demo1/demo2/demo3` IDs.
- Tour loading now replaces state with database results even when there are zero rows.
- Database loading errors are surfaced in the admin dashboard instead of silently keeping demo records.
- Save/Edit refuses non-UUID demo IDs and normalizes empty return dates/image URLs.
- Delete refuses demo IDs, reports booking lookup errors, and only deletes a valid UUID tour with no bookings.

## Deploy correctly
This ZIP is the **React/Vite source project**, not a prebuilt Netlify Drop folder. Do not upload this source ZIP to the manual Drop uploader as if it were built site files.

Recommended: update the source in the GitHub repository connected to Netlify and let Netlify build it using:
- Build command: `npm run build`
- Publish directory: `dist`

If deploying manually, first run `npm install` and `npm run build` in an environment with internet access and upload the contents of `dist/` to Netlify Drop.

Keep the existing Netlify environment variables configured:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY` (the public/anon key only; never use service_role/secret)

## Database
The tours already exist in Supabase. Do not reinsert them or run destructive SQL for this frontend fix. Confirm each tour's `id` is a UUID in `public.tours`.
