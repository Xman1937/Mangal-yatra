# Mangal Yatra
React + Vite temple group tour booking website, designed for Netlify and Supabase.

## Run
1. Install Node.js 20 or newer.
2. Extract ZIP and run `npm install`.
3. Copy `.env.example` to `.env`; add your Supabase project URL and anon key.
4. Run `npm run dev`; create a production build with `npm run build`.

Without Supabase settings, the homepage displays sample tours for visual preview. Real bookings and admin actions require Supabase.

## Supabase setup
1. Create a Supabase project.
2. Run `supabase/setup.sql` in SQL Editor.
3. In Supabase Auth, create an admin user using email/password.
4. Copy that user's UUID and run: `insert into public.admin_profiles(user_id) values ('YOUR-ADMIN-AUTH-UUID');`
5. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in `.env` and Netlify environment variables.
6. Sign in at `/admin`, then add your real UPI ID and QR under UPI Settings.

## Important before real bookings
This is a starter implementation, not a completed production security audit. UPI payments are manual; a screenshot is not proof of payment. The included database schema provides admin-reviewed payments and a basic capacity check, but does not yet implement a fully atomic reservation/expiry system or OTP-protected passenger lookup. The My Booking lookup uses booking reference plus mobile number, with no OTP as requested. Keep these details private and avoid showing sensitive passenger information in the status page. Do not accept live payments until these controls, cancellation/refund handling, and concurrency tests have been completed. Verify the actual bank credit before approving any payment.
