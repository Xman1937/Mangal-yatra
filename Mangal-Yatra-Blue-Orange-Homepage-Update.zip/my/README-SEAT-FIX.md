Mangal Yatra seat-count fix

1. Run supabase/seat-count-fix.sql in Supabase SQL Editor.
2. Build the React/Vite project and deploy the generated dist output to Netlify.
3. Cards call get_tour_available_seats() and booking creation calls create_booking_with_capacity().

Seat policy: bookings in pending, verification_pending and confirmed states reserve seats. Cancelled, expired, or payment-rejected bookings do not reserve seats.

This ZIP is source code, not a prebuilt dist folder. It has not been built or tested against your live Supabase project. Test in a staging project before production.
