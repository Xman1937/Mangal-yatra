create extension if not exists pgcrypto;
create table if not exists public.admin_profiles(user_id uuid primary key references auth.users(id) on delete cascade,created_at timestamptz default now());
create table if not exists public.tours(id uuid primary key default gen_random_uuid(),name text not null,slug text unique not null,description text default '',departure_city text not null,departure_date date not null,return_date date,price numeric(10,2) not null check(price>0),capacity int not null default 40 check(capacity between 1 and 100),image_url text,itinerary text default '',status text not null default 'draft' check(status in('draft','published','full','confirmed','cancelled','completed')),created_at timestamptz default now(),updated_at timestamptz default now());
create table if not exists public.bookings(id uuid primary key default gen_random_uuid(),tour_id uuid not null references public.tours(id) on delete restrict,booking_reference text unique not null,passenger_name text not null,mobile text not null,passenger_count int not null check(passenger_count between 1 and 6),pickup_point text not null,total_amount numeric(10,2) not null check(total_amount>0),status text not null default 'pending' check(status in('pending','verification_pending','confirmed','cancelled','expired')),payment_status text not null default 'not_submitted' check(payment_status in('not_submitted','verification_pending','paid','rejected','refund_pending','refunded')),created_at timestamptz default now());
create table if not exists public.payment_submissions(id uuid primary key default gen_random_uuid(),booking_id uuid not null references public.bookings(id) on delete restrict,transaction_id text not null,proof_path text,amount numeric(10,2) not null,status text not null default 'pending' check(status in('pending','approved','rejected')),review_note text,reviewed_by uuid references auth.users(id),reviewed_at timestamptz,created_at timestamptz default now());
create unique index if not exists unique_approved_txn on public.payment_submissions(lower(transaction_id)) where status='approved';
create table if not exists public.site_settings(key text primary key,value text not null default '',updated_at timestamptz default now());
create table if not exists public.admin_audit_logs(id uuid primary key default gen_random_uuid(),admin_user_id uuid references auth.users(id),action text not null,record_type text not null,record_id text,details jsonb default '{}'::jsonb,created_at timestamptz default now());
create index if not exists tours_status_date on public.tours(status,departure_date);
create index if not exists bookings_tour on public.bookings(tour_id);
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.admin_profiles where user_id=auth.uid()) $$;
alter table public.admin_profiles enable row level security; alter table public.tours enable row level security; alter table public.bookings enable row level security; alter table public.payment_submissions enable row level security; alter table public.site_settings enable row level security; alter table public.admin_audit_logs enable row level security;
create policy "read published tours" on public.tours for select using(status in('published','full','confirmed') or public.is_admin());
create policy "admin tour manage" on public.tours for all using(public.is_admin()) with check(public.is_admin());
create policy "admin profile read" on public.admin_profiles for select using(auth.uid()=user_id or public.is_admin());
create policy "admin booking manage" on public.bookings for all using(public.is_admin()) with check(public.is_admin());
create policy "admin payment manage" on public.payment_submissions for all using(public.is_admin()) with check(public.is_admin());
create policy "public read payment settings" on public.site_settings for select using(key in('upi_id','payee_name','qr_url'));
create policy "admin settings manage" on public.site_settings for all using(public.is_admin()) with check(public.is_admin());
create policy "admin audit read" on public.admin_audit_logs for select using(public.is_admin());
insert into public.site_settings(key,value) values('payee_name','Mangal Yatra'),('upi_id',''),('qr_url','') on conflict(key) do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('payment-proofs','payment-proofs',false,5242880,array['image/png','image/jpeg','image/webp','application/pdf']) on conflict(id) do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('site-assets','site-assets',true,5242880,array['image/png','image/jpeg','image/webp']) on conflict(id) do nothing;
create policy "admin private proof files" on storage.objects for all using(bucket_id='payment-proofs' and public.is_admin()) with check(bucket_id='payment-proofs' and public.is_admin());
create policy "public site images" on storage.objects for select using(bucket_id='site-assets');
create policy "admin site image upload" on storage.objects for insert with check(bucket_id='site-assets' and public.is_admin());
create or replace function public.admin_review_payment(p_submission_id uuid,p_new_status text,p_note text default '') returns void language plpgsql security definer set search_path=public as $$
declare p public.payment_submissions%rowtype; b public.bookings%rowtype; paid_count int; cap int;
begin
 if not public.is_admin() then raise exception 'Not authorised'; end if;
 if p_new_status not in('approved','rejected') then raise exception 'Invalid status'; end if;
 select * into p from public.payment_submissions where id=p_submission_id for update;
 if not found then raise exception 'Payment not found'; end if;
 select * into b from public.bookings where id=p.booking_id for update;
 if p_new_status='approved' then
  if p.amount<>b.total_amount then raise exception 'Amount does not match booking'; end if;
  if exists(select 1 from public.payment_submissions where lower(transaction_id)=lower(p.transaction_id) and status='approved' and id<>p.id) then raise exception 'Transaction ID already used'; end if;
  select capacity into cap from public.tours where id=b.tour_id for update;
  select coalesce(sum(passenger_count),0)::int into paid_count from public.bookings where tour_id=b.tour_id and payment_status='paid' and id<>b.id;
  if paid_count+b.passenger_count>cap then raise exception 'Not enough seats'; end if;
  update public.payment_submissions set status='approved',review_note=p_note,reviewed_by=auth.uid(),reviewed_at=now() where id=p.id;
  update public.bookings set payment_status='paid',status='confirmed' where id=b.id;
  select coalesce(sum(passenger_count),0)::int into paid_count from public.bookings where tour_id=b.tour_id and payment_status='paid';
  if paid_count>=cap then update public.tours set status='full',updated_at=now() where id=b.tour_id and status='published'; end if;
 else
  update public.payment_submissions set status='rejected',review_note=p_note,reviewed_by=auth.uid(),reviewed_at=now() where id=p.id;
  update public.bookings set payment_status='rejected',status='pending' where id=b.id;
 end if;
 insert into public.admin_audit_logs(admin_user_id,action,record_type,record_id,details) values(auth.uid(),'payment_'||p_new_status,'payment_submissions',p.id::text,jsonb_build_object('booking_id',b.id,'note',p_note));
end $$;
revoke all on function public.admin_review_payment(uuid,text,text) from public; grant execute on function public.admin_review_payment(uuid,text,text) to authenticated;
-- After creating your admin in Supabase Auth, run:
-- insert into public.admin_profiles(user_id) values ('YOUR-ADMIN-AUTH-UUID');
