-- Mangal Yatra: live seat counts and atomic booking creation
-- Run in Supabase SQL Editor. Existing bookings in pending/verification_pending/confirmed
-- statuses reserve seats; cancelled/expired/rejected bookings do not.

CREATE OR REPLACE FUNCTION public.get_tour_available_seats(p_tour_id uuid)
RETURNS integer
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  cap integer;
  occupied integer;
BEGIN
  SELECT capacity INTO cap
  FROM public.tours
  WHERE id = p_tour_id AND status IN ('published','full','confirmed');

  IF cap IS NULL THEN
    RETURN 0;
  END IF;

  SELECT COALESCE(SUM(passenger_count), 0)::integer INTO occupied
  FROM public.bookings
  WHERE tour_id = p_tour_id
    AND status NOT IN ('cancelled','expired')
    AND payment_status <> 'rejected';

  RETURN GREATEST(cap - occupied, 0);
END;
$$;

CREATE OR REPLACE FUNCTION public.create_booking_with_capacity(
  p_tour_id uuid,
  p_booking_reference text,
  p_passenger_name text,
  p_mobile text,
  p_passenger_count integer,
  p_pickup_point text,
  p_total_amount numeric
)
RETURNS public.bookings
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  t public.tours%ROWTYPE;
  occupied integer;
  new_booking public.bookings%ROWTYPE;
BEGIN
  IF p_passenger_count IS NULL OR p_passenger_count < 1 OR p_passenger_count > 6 THEN
    RAISE EXCEPTION 'Passenger count must be between 1 and 6';
  END IF;

  SELECT * INTO t FROM public.tours
  WHERE id = p_tour_id AND status = 'published'
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Tour is not available for booking';
  END IF;

  SELECT COALESCE(SUM(passenger_count), 0)::integer INTO occupied
  FROM public.bookings
  WHERE tour_id = p_tour_id
    AND status NOT IN ('cancelled','expired')
    AND payment_status <> 'rejected';

  IF occupied + p_passenger_count > t.capacity THEN
    RAISE EXCEPTION 'Not enough seats';
  END IF;

  IF p_total_amount <> (t.price * p_passenger_count) THEN
    RAISE EXCEPTION 'Booking amount does not match tour price';
  END IF;

  INSERT INTO public.bookings(
    tour_id, booking_reference, passenger_name, mobile,
    passenger_count, pickup_point, total_amount, status, payment_status
  ) VALUES (
    p_tour_id, p_booking_reference, p_passenger_name, p_mobile,
    p_passenger_count, p_pickup_point, p_total_amount, 'pending', 'not_submitted'
  )
  RETURNING * INTO new_booking;

  RETURN new_booking;
END;
$$;

REVOKE ALL ON FUNCTION public.get_tour_available_seats(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_tour_available_seats(uuid) TO anon, authenticated;
REVOKE ALL ON FUNCTION public.create_booking_with_capacity(uuid,text,text,text,integer,text,numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_booking_with_capacity(uuid,text,text,text,integer,text,numeric) TO anon, authenticated;
