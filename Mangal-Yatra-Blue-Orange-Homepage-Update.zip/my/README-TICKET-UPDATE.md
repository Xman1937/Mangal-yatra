# Mangal Yatra — Professional Ticket Update

This update changes the My Booking lookup result and the ticket print/PDF layout.

## What changed
- Professional blue/orange travel ticket layout.
- Booking reference QR code (QR is generated from the booking reference and tour details).
- Passenger, mobile, tour, departure/return dates, pickup point, passenger count, amount, and payment method.
- Ticket action is only available when `payment_status = paid` AND `status = confirmed`.
- Booking lookup shows clearer status and a professional ticket-download button.

## Important
This is the React/Vite source project, not a prebuilt Netlify `dist` folder. Netlify's manual drag-and-drop deploy expects the built output, not this source ZIP. To deploy, open this project in an online React/Vite workspace (e.g. StackBlitz), allow dependencies to install, run `npm run build`, then upload the generated `dist` folder contents to Netlify. The build was not run in this environment because Vite dependencies were unavailable here.

The QR code uses an online QR image endpoint and encodes the ticket reference/tour text; it is not a live booking-status verification endpoint. Do not treat QR scanning alone as proof of payment.
